﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            //reflection code 
            Type t = typeof(Emoployee);
            Console.WriteLine(t.Name);
            //to get properties informnation using the reflection
            PropertyInfo[] properties = t.GetProperties();
            Console.WriteLine("properties information");
            foreach (PropertyInfo property in properties)
            {
                Console.WriteLine( property.PropertyType.Name+"        "+property.Name);
            }
            //to get method informnation using the reflection
            Console.WriteLine("methods information");
            Console.WriteLine();
            MethodInfo[] methods = t.GetMethods();
            foreach(MethodInfo method in methods)
            {
                //Console.WriteLine(method.Name);
                Console.WriteLine(method.ReturnType.Name+":"+method.Name);
            }
            //to get constructor informnation using the reflection
            Console.WriteLine("constuctor information");
            ConstructorInfo[] constructors = t.GetConstructors();
            foreach(ConstructorInfo constructor in constructors)
            {
                Console.WriteLine(constructor.ToString());
            }

            Console.ReadKey();
        }
    }
   public class Emoployee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        Emoployee(int Id,string Name)
        {
            this.Id = Id;
            this.Name = Name;

        }
       public void CallTo()
        {
            Console.WriteLine(Id);
        }
        public void callName()
        {
            Console.WriteLine(Name);
        }
    }
}
